package com.sg.rest.demo.web.jpql;

import static com.sg.rest.demo.web.jpql.bean.SortType.ASC;
import static com.sg.rest.demo.web.jpql.bean.SortType.DESC;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.util.Assert;

import com.sg.rest.demo.web.jpql.bean.FieldSorting;
import com.sg.rest.demo.web.jpql.bean.SearchCriteria;
import com.sg.rest.demo.web.jpql.bean.SearchResult;

public class SearchBuilder<R extends JpaSpecificationExecutor<T>, T> {

    private R repository;
    private SearchCriteria searchCriteria;

    public SearchBuilder(final R repository, final SearchCriteria searchCriteria) {
        Assert.notNull(repository, "The repository parameter is required");
        validate(searchCriteria);
        this.repository = repository;
        this.searchCriteria = searchCriteria;
    }

    /**
     * Validates if {@code searchCriteria} data is valid
     * 
     * @param searchCriteria the (@code searchCriteria} data to be validated
     */
    private void validate(final SearchCriteria searchCriteria) {
        Assert.notNull(searchCriteria, "The searchCriteria parameter is required");
        if (searchCriteria.getQuery().getCriterias() == null || searchCriteria.getQuery().getCriterias().isEmpty())
            throw new IllegalArgumentException("No criteria found");
    }

    /**
     * Builds attributes for the {@code Pageable} based on {@code from}, and {@code size}
     * 
     * @return a {@link Pageable}
     */
    private Pageable buildPageable() {
        int from = searchCriteria.getFrom() - 1; // Calculate the searching page
        int size = searchCriteria.getSize() < 1 ? 20 : searchCriteria.getSize();
        from = from < 0 ? 0 : from;

        // Add sort fields if had
        List<Order> orders = getOrders(searchCriteria.getSortFields());
        if (orders.isEmpty()) {
            return PageRequest.of(from, size);
        }
        return PageRequest.of(from, size, Sort.by(orders));
    }

    private List<Order> getOrders(final List<FieldSorting> fields) {
        if (fields == null || fields.isEmpty()) {
            return Collections.emptyList();
        }

        List<Order> orders = new ArrayList<>();
        for (FieldSorting field : fields) {
            if (StringUtils.isBlank(field.getField()) || StringUtils.isBlank(field.getDirection())) {
                continue;
            }

            if (ASC.type().equalsIgnoreCase(field.getDirection())) {
                orders.add(new Order(Direction.ASC, field.getField()));
            } else if (DESC.type().equalsIgnoreCase(field.getDirection())) {
                orders.add(new Order(Direction.DESC, field.getField()));
            }
        }
        return orders;
    }

    private SearchResult<T> parser(final Page<T> page) {
        SearchResult<T> result = new SearchResult<>();
        result.setOffset(page.getPageable().getOffset());
        result.setPageSize(page.getPageable().getPageSize());
        result.setTotal(page.getTotalElements());
        result.setTotalPages(page.getTotalPages());
        result.setContent(page.getContent());
        return result;
    }

    /**
     * Searches data based on dynamic criteria
     * 
     * @return a {@link SearchResult} of T
     */
    public SearchResult<T> search() {
        Specification<T> specification = new SpecificationBuilder<T>(searchCriteria).build();
        return parser(repository.findAll(specification, buildPageable()));
    }

}
