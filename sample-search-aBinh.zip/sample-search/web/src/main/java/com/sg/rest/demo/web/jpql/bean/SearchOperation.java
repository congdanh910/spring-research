package com.sg.rest.demo.web.jpql.bean;

public enum SearchOperation {
    EQUALITY, NEGATION, GREATER_THAN, LESS_THAN, LIKE, STARTS_WITH, ENDS_WITH, CONTAINS, BETWEEN, IN;

    /**
     * It is to define constant for the {@code Operator}
     */
    public enum Operator {

        /** Define {@code OR} enum */
        OR("OR", "Combines 2 causes with {@code OR}"),

        /** Define {@code AND} enum */
        AND("AND", "Combines 2 causes with {@code AND}");

        private String value;
        private String description;

        private Operator(String value, String description) {
            this.value = value;
            this.description = description;
        }

        /**
         * @return the value of {@code operator}
         */
        public String value() {
            return value;
        }

        /**
         * @return the description
         */
        public String description() {
            return description;
        }

        /**
         * @param type the type should be looked up
         * @return a {@link Operator}
         */
        public static Operator fromType(String value) {
            for (Operator o : Operator.values()) {
                if (o.value.equals(value)) {
                    return o;
                }
            }
            throw new IllegalArgumentException("Cannot create enum from " + value + " value");
        }
    }
}
