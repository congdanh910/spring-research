package com.sg.rest.demo.web.jpql.bean;

import java.util.List;

public class SearchResult<T> {

    private long offset;
    private int pageSize;
    private long total;
    private int totalPages;
    private List<T> content;

    public SearchResult() {
        // Default constructor
    }

    /**
     * Initializes attributes of the {@code SearchResult}
     * 
     * @param offset
     * @param size
     * @param total
     * @param totalPages
     * @param content
     */
    public SearchResult(final long offset, final int pageSize, final long total, final int totalPages,
            final List<T> content) {
        this.offset = offset;
        this.pageSize = pageSize;
        this.total = total;
        this.totalPages = totalPages;
        this.content = content;
    }

    /**
     * @return the offset
     */
    public long getOffset() {
        return offset;
    }

    /**
     * @param offset the offset to set
     */
    public void setOffset(long offset) {
        this.offset = offset;
    }

    /**
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * @param pageSize the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * @return the total
     */
    public long getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(long total) {
        this.total = total;
    }

    /**
     * @return the totalPages
     */
    public int getTotalPages() {
        return totalPages;
    }

    /**
     * @param totalPages the totalPages to set
     */
    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    /**
     * @return the content
     */
    public List<T> getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(List<T> content) {
        this.content = content;
    }

}
