package com.sg.rest.demo.web.jpql;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sg.rest.demo.web.jpql.bean.Criteria;

/**
 * It is create a {@code Predicate} based on dynamic criteria
 * 
 * @param <T> the type of a specific {@code domain}
 */
public class GenericSpecification<T> implements Specification<T> {

    private static final long serialVersionUID = -3717957526467673121L;
    private transient Criteria criteria;

    /**
     * Initializes the attributes of the {@code GenericSpecification}
     * 
     * @param criteria a {@code JCriteria}
     */
    public GenericSpecification(final Criteria criteria) {
        super();
        this.criteria = criteria;
    }

    /**
     * @return a {@link Criteria}
     */
    public Criteria getCriteria() {
        return criteria;
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Predicate toPredicate(final Root<T> root, final CriteriaQuery<?> criteriaQuery,
            final CriteriaBuilder builder) {
        Expression expression = root.get(criteria.getKey());
        switch (criteria.getOperation()) {
            case EQUALITY:
                return builder.equal(expression, criteria.getValue());
            case NEGATION:
                return builder.notEqual(expression, criteria.getValue());
            case GREATER_THAN:
                return builder.greaterThan(expression, criteria.getValue().toString());
            case LESS_THAN:
                return builder.lessThan(expression, criteria.getValue().toString());
            case LIKE:
                return builder.like(expression, criteria.getValue().toString());
            case STARTS_WITH:
                return builder.like(expression, criteria.getValue().toString() + "%");
            case ENDS_WITH:
                return builder.like(expression, "%" + criteria.getValue().toString());
            case CONTAINS:
                return builder.like(expression, "%" + criteria.getValue().toString() + "%");
            case BETWEEN:
                if (expression.getJavaType() == LocalDate.class) {
                    LocalDate from = LocalDate.parse(criteria.getValue().toString());
                    LocalDate to = LocalDate.parse(criteria.getSecondValue().toString());
                    return builder.between(expression, from, to);
                }
                if (expression.getJavaType() == LocalDateTime.class) {
                    LocalDateTime from = LocalDateTime.of(LocalDate.parse(criteria.getValue().toString()),
                            LocalTime.MIDNIGHT);
                    LocalDateTime to = LocalDateTime.of(LocalDate.parse(criteria.getSecondValue().toString()),
                            LocalTime.MAX);
                    return builder.between(expression, from, to);
                }
                throw new IllegalArgumentException("No data type for operation:" + criteria.getOperation());
            case IN:
                return expression.in(criteria.getValue());
            default:
                throw new IllegalArgumentException("Doesn't support operation:" + criteria.getOperation());
        }
    }
}
