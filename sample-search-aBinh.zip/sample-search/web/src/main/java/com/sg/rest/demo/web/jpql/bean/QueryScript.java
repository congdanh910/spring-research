package com.sg.rest.demo.web.jpql.bean;

import java.util.List;

/**
 * It is to define attributes of the {@code QueryScript}
 */
public class QueryScript {

    private String operator;
    
    private List<QueryElement> criterias;

    /**
     * @return the operator
     */
    public String getOperator() {
        return operator;
    }

    /**
     * @param operator the operator to set
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * @return the criterias
     */
    public List<QueryElement> getCriterias() {
        return criterias;
    }

    /**
     * @param criterias the criterias to set
     */
    public void setCriterias(List<QueryElement> criterias) {
        this.criterias = criterias;
    }

}
