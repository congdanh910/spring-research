package com.sg.rest.demo.web.jpql.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * It is to deserialize a JSON from the payload of request
 */
public class SearchCriteria {

    private int from;
    private int size;
    @JsonProperty("sort_fields")
    private List<FieldSorting> sortFields;
    private QueryScript query;

    /**
     * @return the from
     */
    public int getFrom() {
        return from;
    }

    /**
     * @param from the from to set
     */
    public void setFrom(int from) {
        this.from = from;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

    /**
     * @return the sortFields
     */
    public List<FieldSorting> getSortFields() {
        return sortFields;
    }

    /**
     * @param sortFields the sortFields to set
     */
    public void setSortFields(List<FieldSorting> sortFields) {
        this.sortFields = sortFields;
    }

    /**
     * @return the query
     */
    public QueryScript getQuery() {
        return query;
    }

    /**
     * @param query the query to set
     */
    public void setQuery(QueryScript query) {
        this.query = query;
    }

}
