package com.sg.rest.demo.web.jpql.bean;

/**
 * It is to define attributes to build a {@code Predicate}
 */
public class Criteria {

    private String key;
    private SearchOperation operation;
    private Object value;
    private Object secondValue;

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return the operation
     */
    public SearchOperation getOperation() {
        return operation;
    }

    /**
     * @param operation the operation to set
     */
    public void setOperation(SearchOperation operation) {
        this.operation = operation;
    }

    /**
     * @return the value
     */
    public Object getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(Object value) {
        this.value = value;
    }

    /**
     * @return the secondValue
     */
    public Object getSecondValue() {
        return secondValue;
    }

    /**
     * @param secondValue the secondValue to set
     */
    public void setSecondValue(Object secondValue) {
        this.secondValue = secondValue;
    }

    @Override
    public String toString() {
        return "Criteria[key=" + key + ", value=" + value + "]";
    }
}
