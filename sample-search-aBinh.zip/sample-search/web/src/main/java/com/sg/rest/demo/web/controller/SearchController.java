package com.sg.rest.demo.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sg.rest.demo.web.domain.User;
import com.sg.rest.demo.web.jpql.SearchBuilder;
import com.sg.rest.demo.web.jpql.bean.SearchCriteria;
import com.sg.rest.demo.web.jpql.bean.SearchResult;
import com.sg.rest.demo.web.repository.UserRepository;

@RestController
@RequestMapping("/api")
public class SearchController {

    private static final Logger LOG = LoggerFactory.getLogger(SearchController.class);

    @Autowired
    UserRepository userRepository;

    @GetMapping("/req/body")
    public ResponseEntity<Object> getRequestBody(@RequestBody SearchCriteria searchCriteria) {
        LOG.info("getRequestBody searchCriteria={}", searchCriteria);

        return new ResponseEntity<>(search(searchCriteria), HttpStatus.OK);
    }

    private SearchResult<User> search(SearchCriteria searchCriteria) {

        // Specification<User> s1 = hasAttr("firstName", "Nhan")
        // Specification<User> s2 = hasAttr("lastName", "danh")
        // Specification<User> s3 = hasAttr("password", "2")
        // Specification<User> specs = s1.or(s2).and(s3)

        SearchBuilder<?, User> builder = new SearchBuilder<>(userRepository, searchCriteria);
        return builder.search();
    }

}
