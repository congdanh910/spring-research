package com.sg.rest.demo.web.jpql;

import static com.sg.rest.demo.web.jpql.bean.SearchOperation.Operator.AND;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.data.jpa.domain.Specification;

import com.sg.rest.demo.web.jpql.bean.Criteria;
import com.sg.rest.demo.web.jpql.bean.QueryScript;
import com.sg.rest.demo.web.jpql.bean.QueryElement;
import com.sg.rest.demo.web.jpql.bean.SearchCriteria;

/**
 * It is to build a dynamic {@code Specification} for searching a specific domain
 * 
 * @param <T> type of a {@code domain}
 */
public class SpecificationBuilder<T> {

    private QueryScript query;

    public SpecificationBuilder(SearchCriteria searchCriteria) {
        if (null == searchCriteria || searchCriteria.getQuery() == null
                || searchCriteria.getQuery().getCriterias() == null
                || searchCriteria.getQuery().getCriterias().isEmpty())
            throw new IllegalArgumentException("SearchCriteria is missing or Criteria not found");
        this.query = searchCriteria.getQuery();
    }

    private Specification<T> create(String operator, List<Criteria> criteraElms) {
        List<Specification<T>> specs = transform(criteraElms);
        Specification<T> result = specs.get(0);
        for (int i = 1; i < specs.size(); i++) {
            result = (AND.value().equalsIgnoreCase(operator)) ? Specification.where(result).and(specs.get(i))
                    : Specification.where(result).or(specs.get(i));
        }
        return result;
    }

    private final List<Specification<T>> transform(List<Criteria> criteraElms) {
        Function<Criteria, Specification<T>> converter = GenericSpecification::new;
        return criteraElms.stream().map(converter).collect(Collectors.toCollection(ArrayList::new));
    }

    /**
     * Builds a {@code Specification} based on dynamic criteria
     * 
     * @return a {@link Specification} of T
     */
    public Specification<T> build() {
        List<QueryElement> criterias = query.getCriterias();
        Specification<T> specs = create(criterias.get(0).getOperator(), criterias.get(0).getCriterias());
        for (int i = 1; i < criterias.size(); i++) {
            Specification<T> children = create(criterias.get(i).getOperator(), criterias.get(i).getCriterias());
            specs = (AND.value().equalsIgnoreCase(query.getOperator())) ? Specification.where(specs).and(children)
                    : Specification.where(specs).or(children);
        }
        return specs;
    }

}
