package com.sg.rest.demo.web.jpql.bean;

/**
 * It is to define constant for the {@code Operator}
 */
public enum SortType {

    /** Defines {@code ascending} sort constant */
    ASC("ASC", "Field should be sort by ascending"),

    /** Defines {@code descending} sort constant */
    DESC("DESC", "Field should be sort by descending");

    private String type;
    private String description;

    private SortType(String type, String description) {
        this.type = type;
        this.description = description;
    }

    /**
     * @return the type
     */
    public String type() {
        return type;
    }

    /**
     * @return the description
     */
    public String description() {
        return description;
    }

    /**
     * @param type the type should be looked up
     * @return a {@link SortType}
     */
    public static SortType fromType(String type) {
        for (SortType o : SortType.values()) {
            if (o.type.equals(type)) {
                return o;
            }
        }
        throw new IllegalArgumentException("Cannot create enum from " + type + " value");
    }
}
