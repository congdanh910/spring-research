package com.sg.rest.demo.web.jpql.bean;

import java.util.List;

/**
 * It is to define attributes to combine {@code Predicate} for the whole 'where cause'
 */
public class QueryElement {

    private String operator;
    private List<Criteria> criterias;

    /**
     * @return the operator
     */
    public String getOperator() {
        return operator;
    }

    /**
     * @param operator the operator to set
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * @return the criterias
     */
    public List<Criteria> getCriterias() {
        return criterias;
    }

    /**
     * @param criterias the criterias to set
     */
    public void setCriterias(List<Criteria> criterias) {
        this.criterias = criterias;
    }

    public String toString() {
        return "QueryChild[operator=" + operator + ", criterias=" + criterias + "]";
    }
}
